// Runs OpenSCAD (WASM) off the UI thread. A fresh instance per render, since callMain exits the runtime.
self.onmessage=async({data:{files,main,defs}})=>{
  const log=[];
  try{
    const mod=await import('./openscad.js');
    const factory=mod.default||self.OpenSCAD;
    const run=async backend=>{
      const inst=await factory({noInitialRun:true,print:t=>log.push(t),printErr:t=>log.push(t)});
      const FS=inst.FS;
      const mk=p=>{let c='';for(const s of p.split('/').slice(0,-1).filter(Boolean)){c+='/'+s;try{FS.mkdir(c)}catch{}}};
      for(const [p,d] of Object.entries(files))for(const r of ['/work/','/libraries/']){mk(r+p);FS.writeFile(r+p,d)}
      const args=['/work/'+main,'-o','/out.stl',...(backend?['--backend=manifold']:[]),...defs.flatMap(d=>['-D',d])];
      let code;try{code=inst.callMain(args)}catch(e){code=e&&e.status!==undefined?e.status:1}
      try{return {stl:FS.readFile('/out.stl'),code}}catch{return {code}}
    };
    let r=await run(true);
    if(!r.stl&&log.some(l=>/backend/i.test(l)&&/unknown|invalid|unrecogni/i.test(l)))r=await run(false);
    if(!r.stl)return self.postMessage({error:'Render failed (exit '+r.code+'). 2D-only models cannot export STL.',log});
    self.postMessage({stl:r.stl,log},[r.stl.buffer]);
  }catch(e){self.postMessage({error:String(e&&e.message||e),log})}
};
