// Minimal zip reader (stored + deflate) using the browser's DecompressionStream.
export async function unzip(buf){
  const dv=new DataView(buf),u8=new Uint8Array(buf),out={};
  let e=u8.length-22;while(e>=0&&dv.getUint32(e,true)!==0x06054b50)e--;
  if(e<0)throw new Error('Not a zip file');
  const n=dv.getUint16(e+10,true);let p=dv.getUint32(e+16,true);
  for(let i=0;i<n;i++){
    const method=dv.getUint16(p+10,true),cs=dv.getUint32(p+20,true),nl=dv.getUint16(p+28,true),xl=dv.getUint16(p+30,true),cl=dv.getUint16(p+32,true),off=dv.getUint32(p+42,true);
    const name=new TextDecoder().decode(u8.subarray(p+46,p+46+nl));p+=46+nl+xl+cl;
    if(name.endsWith('/')||name.startsWith('__MACOSX'))continue;
    const s=off+30+dv.getUint16(off+26,true)+dv.getUint16(off+28,true),raw=u8.subarray(s,s+cs);
    out[name]=method===0?raw.slice():new Uint8Array(await new Response(new Blob([raw]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer());
  }
  return out;
}
