// Dependency-free WebGL2 STL viewer: flat shading, orbit / pinch-zoom / two-finger pan. Z is up (OpenSCAD).
export class Viewer{
  constructor(c){
    this.c=c;const gl=this.gl=c.getContext('webgl2',{antialias:true});
    const sh=(t,s)=>{const o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);return o};
    const pr=this.pr=gl.createProgram();
    gl.attachShader(pr,sh(gl.VERTEX_SHADER,`#version 300 es
in vec3 p;uniform mat4 mv,pj;out vec3 v;void main(){vec4 q=mv*vec4(p,1);v=q.xyz;gl_Position=pj*q;}`));
    gl.attachShader(pr,sh(gl.FRAGMENT_SHADER,`#version 300 es
precision highp float;in vec3 v;out vec4 o;void main(){
vec3 n=normalize(cross(dFdx(v),dFdy(v)));float d=abs(n.z);
vec3 L=normalize(vec3(.4,.6,.7));float k=.3+.55*abs(dot(n,L))+.25*d*d;
o=vec4(vec3(.95,.78,.25)*k,1);}`));
    gl.linkProgram(pr);gl.useProgram(pr);
    this.vao=gl.createVertexArray();this.buf=gl.createBuffer();this.n=0;
    this.yaw=-.8;this.pitch=.6;this.dist=3;this.pan=[0,0,0];this.r=1;this.ctr=[0,0,0];
    gl.enable(gl.DEPTH_TEST);
    const ptr=new Map();
    c.onpointerdown=e=>{c.setPointerCapture(e.pointerId);ptr.set(e.pointerId,[e.clientX,e.clientY])};
    c.onpointerup=c.onpointercancel=e=>ptr.delete(e.pointerId);
    c.onpointermove=e=>{
      if(!ptr.has(e.pointerId))return;
      const old=[...ptr.values()],prev=ptr.get(e.pointerId);ptr.set(e.pointerId,[e.clientX,e.clientY]);
      if(ptr.size===1){this.yaw-=(e.clientX-prev[0])*.01;this.pitch=Math.max(-1.5,Math.min(1.5,this.pitch+(e.clientY-prev[1])*.01))}
      else if(ptr.size===2){
        const now=[...ptr.values()],d0=Math.hypot(old[0][0]-old[1][0],old[0][1]-old[1][1]),d1=Math.hypot(now[0][0]-now[1][0],now[0][1]-now[1][1]);
        if(d0>0&&d1>0)this.dist=Math.max(.2,this.dist*d0/d1);
        const s=this.dist*this.r*.0012,dx=(e.clientX-prev[0])/2*s,dy=(e.clientY-prev[1])/2*s;
        const cy=Math.cos(this.yaw),sy=Math.sin(this.yaw);
        this.pan[0]+=-dx*cy-dy*0*sy;this.pan[1]+=dx*sy;this.pan[2]+=dy;
      }
      this.draw();
    };
    c.onwheel=e=>{e.preventDefault();this.dist=Math.max(.2,this.dist*Math.exp(e.deltaY*.001));this.draw()};
    new ResizeObserver(()=>this.draw()).observe(c);
  }
  load(bytes){
    const dv=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
    let v;const nb=dv.getUint32(80,true);
    if(bytes.byteLength===84+50*nb){v=new Float32Array(nb*9);for(let i=0;i<nb;i++)for(let j=0;j<9;j++)v[i*9+j]=dv.getFloat32(84+i*50+12+j*4,true)}
    else{const t=new TextDecoder().decode(bytes),a=[],re=/vertex\s+(\S+)\s+(\S+)\s+(\S+)/g;let m;while(m=re.exec(t))a.push(+m[1],+m[2],+m[3]);v=new Float32Array(a)}
    const lo=[1e30,1e30,1e30],hi=[-1e30,-1e30,-1e30];
    for(let i=0;i<v.length;i++){const k=i%3;lo[k]=Math.min(lo[k],v[i]);hi[k]=Math.max(hi[k],v[i])}
    this.ctr=lo.map((x,i)=>(x+hi[i])/2);this.r=Math.hypot(...hi.map((x,i)=>x-lo[i]))/2||1;
    for(let i=0;i<v.length;i++)v[i]-=this.ctr[i%3];
    const gl=this.gl;gl.bindVertexArray(this.vao);gl.bindBuffer(gl.ARRAY_BUFFER,this.buf);
    gl.bufferData(gl.ARRAY_BUFFER,v,gl.STATIC_DRAW);gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,3,gl.FLOAT,false,0,0);
    this.n=v.length/3;
    if(!this.fit){this.dist=2.8;this.fit=true}
    this.draw();return this.n/3;
  }
  draw(){
    const {c,gl}=this,w=c.clientWidth*devicePixelRatio|0,h=c.clientHeight*devicePixelRatio|0;
    if(c.width!==w||c.height!==h){c.width=w;c.height=h}
    gl.viewport(0,0,w,h);gl.clearColor(.08,.1,.12,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
    if(!this.n)return;
    const D=this.dist*this.r,cp=Math.cos(this.pitch),
      eye=[this.pan[0]+D*cp*Math.cos(this.yaw),this.pan[1]+D*cp*Math.sin(this.yaw),this.pan[2]+D*Math.sin(this.pitch)];
    const f=1/Math.tan(.4),n=this.r*.02,fa=D+this.r*10,pj=[f*h/w,0,0,0,0,f,0,0,0,0,(fa+n)/(n-fa),-1,0,0,2*fa*n/(n-fa),0];
    const T=this.pan,z=norm(sub(eye,T)),x=norm(cross([0,0,1],z)),y=cross(z,x);
    const mv=[x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-dot(x,eye),-dot(y,eye),-dot(z,eye),1];
    gl.uniformMatrix4fv(gl.getUniformLocation(this.pr,'mv'),false,mv);
    gl.uniformMatrix4fv(gl.getUniformLocation(this.pr,'pj'),false,pj);
    gl.bindVertexArray(this.vao);gl.drawArrays(gl.TRIANGLES,0,this.n);
  }
}
const sub=(a,b)=>a.map((v,i)=>v-b[i]),dot=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2],
  cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],
  norm=a=>{const l=Math.hypot(...a)||1;return a.map(v=>v/l)};
