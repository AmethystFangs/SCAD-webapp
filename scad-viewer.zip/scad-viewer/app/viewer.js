// Dependency-free WebGL2 STL viewer: flat shading, orbit / pinch-zoom / pan, optional build plate + scale grid. Z is up (OpenSCAD).
const MVS=`#version 300 es
in vec3 p;in vec3 bc;uniform mat4 mv,pj;out vec3 v;out vec3 b;void main(){vec4 q=mv*vec4(p,1);v=q.xyz;b=bc;gl_Position=pj*q;}`;
const MFS=`#version 300 es
precision highp float;in vec3 v;in vec3 b;uniform vec3 col;uniform float edg;out vec4 o;void main(){
vec3 n=normalize(cross(dFdx(v),dFdy(v)));float d=abs(n.z);
vec3 L=normalize(vec3(.4,.6,.7));float k=.3+.55*abs(dot(n,L))+.25*d*d;
vec3 c=col*k;if(edg>0.){vec3 a=smoothstep(vec3(0.),fwidth(b)*1.3,b);c=mix(vec3(.04),c,min(min(a.x,a.y),a.z));}o=vec4(c,1);}`;
const LVS=`#version 300 es
in vec3 p;uniform mat4 mv,pj;void main(){gl_Position=pj*mv*vec4(p,1);}`;
const LFS=`#version 300 es
precision mediump float;uniform vec4 c;out vec4 o;void main(){o=c;}`;
const AXC=[[.9,.25,.25,1],[.3,.8,.35,1],[.35,.55,.95,1]];

export class Viewer{
  constructor(c){
    this.c=c;const gl=this.gl=c.getContext('webgl2',{antialias:true});
    const sh=(t,s)=>{const o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);return o};
    const mk=(vs,fs,at)=>{const p=gl.createProgram();gl.attachShader(p,sh(gl.VERTEX_SHADER,vs));gl.attachShader(p,sh(gl.FRAGMENT_SHADER,fs));at.forEach((a,i)=>gl.bindAttribLocation(p,i,a));gl.linkProgram(p);return p};
    this.pr=mk(MVS,MFS,['p','bc']);this.pr2=mk(LVS,LFS,['p']);
    this.vao=gl.createVertexArray();this.vao2=gl.createVertexArray();this.buf=gl.createBuffer();this.bbuf=gl.createBuffer();
    this.n=0;this.bg=[.08,.1,.12];this.dark=true;this.col=[.94,.78,.25];this.edg=0;this.cfg=null;this.geo=null;
    this.right=[1,0,0];this.up=[0,0,1];this.yaw=-.8;this.pitch=.6;this.dist=2.8;this.pan=[0,0,0];this.r=1;this.ctr=[0,0,0];
    gl.enable(gl.DEPTH_TEST);
    const ptr=new Map();
    c.onpointerdown=e=>{c.setPointerCapture(e.pointerId);ptr.set(e.pointerId,[e.clientX,e.clientY])};
    c.onpointerup=c.onpointercancel=e=>ptr.delete(e.pointerId);
    c.onpointermove=e=>{
      if(!ptr.has(e.pointerId))return;
      const old=[...ptr.values()],prev=ptr.get(e.pointerId);ptr.set(e.pointerId,[e.clientX,e.clientY]);
      if(ptr.size===1){this.yaw-=(e.clientX-prev[0])*.01;this.pitch=Math.max(-1.5,Math.min(1.5,this.pitch+(e.clientY-prev[1])*.01))}
      else if(ptr.size===2){
        const now=[...ptr.values()],d0=Math.hypot(old[0][0]-old[1][0],old[0][1]-old[1][1]),d1=Math.hypot(now[0][0]-now[1][0],now[0][1]-now[1][1]);
        if(d0>0&&d1>0)this.dist=Math.max(.2,this.dist*d0/d1);
        const s=this.dist*this.r*.85/c.clientHeight,dx=(e.clientX-prev[0])/2*s,dy=(e.clientY-prev[1])/2*s;
        for(let i=0;i<3;i++)this.pan[i]+=-this.right[i]*dx+this.up[i]*dy;
      }
      this.draw();
    };
    c.onwheel=e=>{e.preventDefault();this.dist=Math.max(.2,this.dist*Math.exp(e.deltaY*.001));this.draw()};
    new ResizeObserver(()=>this.draw()).observe(c);
  }
  load(bytes){
    const dv=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
    let v;const nb=dv.getUint32(80,true);
    if(bytes.byteLength===84+50*nb){v=new Float32Array(nb*9);for(let i=0;i<nb;i++)for(let j=0;j<9;j++)v[i*9+j]=dv.getFloat32(84+i*50+12+j*4,true)}
    else{const t=new TextDecoder().decode(bytes),a=[],re=/vertex\s+(\S+)\s+(\S+)\s+(\S+)/g;let m;while(m=re.exec(t))a.push(+m[1],+m[2],+m[3]);v=new Float32Array(a)}
    const lo=[1e30,1e30,1e30],hi=[-1e30,-1e30,-1e30];
    for(let i=0;i<v.length;i++){const k=i%3;lo[k]=Math.min(lo[k],v[i]);hi[k]=Math.max(hi[k],v[i])}
    this.ctr=lo.map((x,i)=>(x+hi[i])/2);this.r=Math.hypot(...hi.map((x,i)=>x-lo[i]))/2||1;
    for(let i=0;i<v.length;i++)v[i]-=this.ctr[i%3];
    const gl=this.gl;gl.bindVertexArray(this.vao);gl.bindBuffer(gl.ARRAY_BUFFER,this.buf);
    gl.bufferData(gl.ARRAY_BUFFER,v,gl.STATIC_DRAW);gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,3,gl.FLOAT,false,0,0);
    this.n=v.length/3;
    const bc=new Float32Array(v.length);for(let i=0;i<v.length;i+=9)bc.set([1,0,0,0,1,0,0,0,1],i);
    gl.bindBuffer(gl.ARRAY_BUFFER,this.bbuf);gl.bufferData(gl.ARRAY_BUFFER,bc,gl.STATIC_DRAW);gl.enableVertexAttribArray(1);gl.vertexAttribPointer(1,3,gl.FLOAT,false,0,0);
    this.buildGrid();
    if(!this.fit){this.view('iso',true);this.fit=true}
    this.draw();return {tris:this.n/3,size:hi.map((x,i)=>x-lo[i])};
  }
  setBg(c,dark){this.bg=c;this.dark=dark;this.draw()}
  setColor(h){this.col=[1,3,5].map(i=>parseInt(h.slice(i,i+2),16)/255);this.draw()}
  setEdges(b){this.edg=b?1:0;this.draw()}
  setGrid(cfg){this.cfg=cfg;this.buildGrid();this.draw()}
  // cfg: plate, lines (bools), pw/pd (mm), shape 'rect'|'circle', origin 'center'|'corner', grid (mm)
  buildGrid(){
    const gl=this.gl,c=this.cfg;if(!c)return;
    const o=this.ctr,circ=c.shape==='circle',W=c.pw,D=circ?c.pw:c.pd,R=W/2;
    const x0=c.origin==='corner'?0:-W/2,y0=c.origin==='corner'?0:-D/2,cx=x0+W/2,cy=y0+D/2;
    const g=Math.max(c.grid,W/300,D/300),minor=[],major=[],fill=[],axes=[];
    const V=(a,x,y,z=0)=>a.push(x-o[0],y-o[1],z-o[2]);
    const seg=(a,x1,y1,x2,y2)=>{V(a,x1,y1);V(a,x2,y2)};
    if(c.lines){
      for(let k=Math.ceil(x0/g-1e-9);k<=Math.floor((x0+W)/g+1e-9);k++){
        const x=k*g,a=k%5===0?major:minor;
        if(circ){const t=R*R-(x-cx)**2;if(t<=0)continue;const q=Math.sqrt(t);seg(a,x,cy-q,x,cy+q)}else seg(a,x,y0,x,y0+D);
      }
      for(let j=Math.ceil(y0/g-1e-9);j<=Math.floor((y0+D)/g+1e-9);j++){
        const y=j*g,a=j%5===0?major:minor;
        if(circ){const t=R*R-(y-cy)**2;if(t<=0)continue;const q=Math.sqrt(t);seg(a,cx-q,y,cx+q,y)}else seg(a,x0,y,x0+W,y);
      }
      for(const d of [[1,0,0],[0,1,0],[0,0,1]]){const a=[];V(a,0,0,0);V(a,d[0]*g*5,d[1]*g*5,d[2]*g*5);axes.push(a)}
    }
    if(c.plate||c.lines){
      if(circ)for(let i=0;i<96;i++){
        const a1=i/96*6.2832,a2=(i+1)/96*6.2832,p1=[cx+R*Math.cos(a1),cy+R*Math.sin(a1)],p2=[cx+R*Math.cos(a2),cy+R*Math.sin(a2)];
        seg(major,...p1,...p2);V(fill,cx,cy,-.05);V(fill,...p1,-.05);V(fill,...p2,-.05);
      }else{
        seg(major,x0,y0,x0+W,y0);seg(major,x0+W,y0,x0+W,y0+D);seg(major,x0+W,y0+D,x0,y0+D);seg(major,x0,y0+D,x0,y0);
        for(const [x,y] of [[x0,y0],[x0+W,y0],[x0+W,y0+D],[x0,y0],[x0+W,y0+D],[x0,y0+D]])V(fill,x,y,-.05);
      }
    }
    const up=(old,arr)=>{if(old)gl.deleteBuffer(old.buf);const b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(arr),gl.STATIC_DRAW);return {buf:b,n:arr.length/3}};
    const G=this.geo||{};
    this.geo={fill:up(G.fill,fill),minor:up(G.minor,minor),major:up(G.major,major),axes:[0,1,2].map(i=>up(G.axes&&G.axes[i],axes[i]||[]))};
  }
  view(n,quiet){
    const P={iso:[-.8,.6],top:[-Math.PI/2,1.5],front:[-Math.PI/2,0],side:[0,0]}[n];
    if(P){this.yaw=P[0];this.pitch=P[1]}
    const c=this.cfg,o=this.ctr;let pr=0;this.pan=[0,0,0];
    if(c&&(c.plate||c.lines)){
      const W=c.pw,D=c.shape==='circle'?c.pw:c.pd;pr=Math.hypot(W,D)/2;
      this.pan=[(c.origin==='corner'?W/2:0)-o[0],(c.origin==='corner'?D/2:0)-o[1],0];
    }
    this.dist=2.8*Math.max(1,pr/this.r);if(!quiet)this.draw();
  }
  draw(){
    const {c,gl}=this,w=c.clientWidth*devicePixelRatio|0,h=c.clientHeight*devicePixelRatio|0;
    if(c.width!==w||c.height!==h){c.width=w;c.height=h}
    gl.viewport(0,0,w,h);gl.clearColor(...this.bg,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
    if(!this.n)return;
    const D=this.dist*this.r,cp=Math.cos(this.pitch),
      eye=[this.pan[0]+D*cp*Math.cos(this.yaw),this.pan[1]+D*cp*Math.sin(this.yaw),this.pan[2]+D*Math.sin(this.pitch)];
    const f=1/Math.tan(.4),n=this.r*.02,fa=D+this.r*10,pj=[f*h/w,0,0,0,0,f,0,0,0,0,(fa+n)/(n-fa),-1,0,0,2*fa*n/(n-fa),0];
    const T=this.pan,z=norm(sub(eye,T)),x=norm(cross([0,0,1],z)),y=cross(z,x);
    const mv=[x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-dot(x,eye),-dot(y,eye),-dot(z,eye),1];
    this.right=x;this.up=y;
    const cfg=this.cfg,G=this.geo,dk=this.dark;
    if(cfg&&G&&(cfg.plate||cfg.lines)){
      const p=this.pr2;gl.useProgram(p);
      gl.uniformMatrix4fv(gl.getUniformLocation(p,'mv'),false,mv);gl.uniformMatrix4fv(gl.getUniformLocation(p,'pj'),false,pj);
      gl.bindVertexArray(this.vao2);gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);
      const cl=gl.getUniformLocation(p,'c');
      const dr=(g,col,mode)=>{if(!g||!g.n)return;gl.bindBuffer(gl.ARRAY_BUFFER,g.buf);gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,3,gl.FLOAT,false,0,0);gl.uniform4fv(cl,col);gl.drawArrays(mode,0,g.n)};
      if(cfg.plate){gl.depthMask(false);dr(G.fill,dk?[.22,.28,.34,.8]:[.68,.74,.8,.85],gl.TRIANGLES);gl.depthMask(true)}
      dr(G.minor,dk?[.4,.47,.54,.7]:[.5,.56,.62,.7],gl.LINES);
      dr(G.major,dk?[.68,.76,.84,.95]:[.28,.35,.43,.95],gl.LINES);
      G.axes.forEach((a,i)=>dr(a,AXC[i],gl.LINES));
      gl.disable(gl.BLEND);
    }
    const p=this.pr;gl.useProgram(p);
    gl.uniformMatrix4fv(gl.getUniformLocation(p,'mv'),false,mv);gl.uniformMatrix4fv(gl.getUniformLocation(p,'pj'),false,pj);
    gl.uniform3fv(gl.getUniformLocation(p,'col'),this.col);gl.uniform1f(gl.getUniformLocation(p,'edg'),this.edg);
    gl.bindVertexArray(this.vao);gl.drawArrays(gl.TRIANGLES,0,this.n);
  }
}
const sub=(a,b)=>a.map((v,i)=>v-b[i]),dot=(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2],
  cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],
  norm=a=>{const l=Math.hypot(...a)||1;return a.map(v=>v/l)};
