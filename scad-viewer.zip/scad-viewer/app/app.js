import {parseCustomizer} from './customizer.js';
import {Viewer} from './viewer.js';
import {unzip} from './zip.js';
const $=s=>document.querySelector(s);
const viewer=new Viewer($('#gl'));
let files={},mainPath=null,params=[],values={},defaults={},worker=null,stl=null,timer=null;
const status=t=>$('#status').textContent=t;
const dec=new TextDecoder();
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const ls={get:(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}},set:(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch{}}};

// ---------- settings: theme, text size, model color, edges ----------
const S={theme:'auto',fs:15,color:'#f0c840',edges:false,plate:false,pw:220,pd:220,shape:'rect',origin:'center',lines:false,grid:10,...ls.get('settings',{})};
const mq=matchMedia('(prefers-color-scheme: dark)');
function applySettings(){
  const dark=S.theme==='dark'||(S.theme==='auto'&&mq.matches);
  document.documentElement.dataset.theme=dark?'dark':'light';
  document.documentElement.style.setProperty('--fs',S.fs+'px');
  $('meta[name=theme-color]').content=dark?'#14181c':'#e4e8ec';
  viewer.setBg(dark?[.08,.1,.12]:[.93,.95,.97],dark);viewer.setColor(S.color);viewer.setEdges(S.edges);viewer.setGrid(S);
  $('#scale').textContent=[S.lines&&`Grid ${S.grid} mm`,S.plate&&`Plate ${S.shape==='circle'?'⌀ '+S.pw:S.pw+' × '+S.pd} mm`].filter(Boolean).join(' · ');
  ls.set('settings',S);
}
mq.onchange=applySettings;
$('#theme').value=S.theme;$('#fs').value=S.fs;$('#color').value=S.color;$('#edges').checked=S.edges;
$('#theme').onchange=e=>{S.theme=e.target.value;applySettings()};
$('#fs').oninput=e=>{S.fs=+e.target.value;applySettings()};
$('#color').oninput=e=>{S.color=e.target.value;applySettings()};
$('#edges').onchange=e=>{S.edges=e.target.checked;applySettings()};
for(const c of ['#f0c840','#e8734a','#5aa9e6','#6cc070','#b48ee0','#d9d9d9','#3a3f45'])
  $('#sw').insertAdjacentHTML('beforeend',`<button data-c="${c}" style="background:${c}" aria-label="${c}"></button>`);
$('#sw').onclick=e=>{const c=e.target.dataset.c;if(c){S.color=c;$('#color').value=c;applySettings()}};
$('#gear').onclick=()=>$('#settings').toggleAttribute('hidden');
$('#views').onclick=e=>{const v=e.target.dataset.v;if(v)viewer.view(v)};
for(const [id,k,t,fit] of [['plate','plate','b',1],['lines','lines','b',1],['pw','pw','n',1],['pd','pd','n',1],['shape','shape','s',1],['origin','origin','s',1],['grid','grid','n',0]]){
  const el=$('#'+id);if(t==='b')el.checked=S[k];else el.value=S[k];
  el.onchange=()=>{S[k]=t==='b'?el.checked:t==='n'?Math.max(1,+el.value||1):el.value;if(k==='pw'||k==='pd')$('#pset').selectedIndex=0;applySettings();if(fit)viewer.view('fit')};
}
$('#pset').value=`${S.pw}×${S.pd}`;if(!$('#pset').value)$('#pset').selectedIndex=0;
$('#pset').onchange=e=>{const m=e.target.value.match(/(\d+)×(\d+)/);if(!m)return;S.pw=+m[1];S.pd=+m[2];$('#pw').value=S.pw;$('#pd').value=S.pd;applySettings();viewer.view('fit')};
applySettings();

// ---------- remember last project (IndexedDB) ----------
const idb=()=>new Promise((res,rej)=>{const r=indexedDB.open('scad',1);r.onupgradeneeded=()=>r.result.createObjectStore('kv');r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});
const kvSet=async(k,v)=>{try{(await idb()).transaction('kv','readwrite').objectStore('kv').put(v,k)}catch{}};
const kvGet=async k=>{try{const d=await idb();return await new Promise(r=>{const q=d.transaction('kv').objectStore('kv').get(k);q.onsuccess=()=>r(q.result);q.onerror=()=>r()})}catch{}};

// ---------- loading ----------
$('#file').onchange=async e=>{
  const f={};
  for(const file of e.target.files){
    const buf=await file.arrayBuffer();
    if(/\.zip$/i.test(file.name))Object.assign(f,await unzip(buf));else f[file.name]=new Uint8Array(buf);
  }
  loadFiles(f);
};
function loadFiles(f,main){
  files=f;
  const scads=Object.keys(files).filter(n=>/\.scad$/i.test(n)&&!n.startsWith('__MACOSX'))
    .sort((a,b)=>a.split('/').length-b.split('/').length||a.localeCompare(b)).slice(0,300);
  if(!scads.length)return status('No .scad file found');
  $('#main').innerHTML=scads.map(n=>`<option>${esc(n)}</option>`).join('');
  $('#main').disabled=false;
  const m=scads.includes(main)?main:scads[0];$('#main').value=m;pick(m);
}
$('#main').onchange=e=>pick(e.target.value);
kvGet('project').then(p=>{if(p?.files)loadFiles(p.files,p.mainPath)});

function pick(name){
  mainPath=name;kvSet('project',{files,mainPath});
  params=parseCustomizer(dec.decode(files[name]));
  defaults=Object.fromEntries(params.map(p=>[p.name,p.def]));
  const saved=ls.get('p:'+name,{});values={};
  for(const p of params)values[p.name]=p.name in saved?saved[p.name]:p.def;
  buildUI();refreshPre();$('#render').disabled=false;render();
}

// ---------- parameter UI ----------
function buildUI(){
  const box=$('#params');box.innerHTML='';
  const groups={};for(const p of params)(groups[p.group]??=[]).push(p);
  for(const [g,list] of Object.entries(groups)){
    const d=document.createElement('details');d.open=true;d.innerHTML=`<summary>${esc(g)}</summary>`;
    for(const p of list)d.append(row(p));box.append(d);
  }
  if(!params.length)box.innerHTML='<small>No Customizer parameters found in this file.</small>';
}
function row(p){
  const r=document.createElement('div');r.className='row';
  const l=document.createElement('label');l.innerHTML=esc(p.name)+(p.desc?`<small>${esc(p.desc)}</small>`:'');
  let inp;
  const set=v=>{values[p.name]=v;persist();if($('#auto').checked){clearTimeout(timer);timer=setTimeout(render,400)}};
  if(p.type==='bool'){inp=document.createElement('input');inp.type='checkbox';inp.checked=values[p.name]===true;inp.onchange=()=>set(inp.checked)}
  else if(p.options){
    inp=document.createElement('select');
    inp.innerHTML=p.options.map(o=>`<option value="${esc(o.v)}">${esc(o.label)}</option>`).join('');
    inp.value=String(values[p.name]);inp.onchange=()=>set(p.type==='number'?+inp.value:inp.value);
  }else if(p.range){
    inp=document.createElement('input');inp.type='range';
    Object.assign(inp,{min:p.range[0],max:p.range[2],step:p.range[1]});inp.value=values[p.name];
    const v=document.createElement('span');v.className='val';v.textContent=inp.value;l.prepend(v);
    inp.oninput=()=>{v.textContent=inp.value};inp.onchange=()=>set(+inp.value);
  }else if(p.type==='number'){inp=document.createElement('input');inp.type='number';inp.step='any';inp.value=values[p.name];inp.onchange=()=>set(+inp.value)}
  else{inp=document.createElement('input');inp.type='text';inp.value=values[p.name];inp.onchange=()=>set(inp.value)}
  r.append(l,inp);return r;
}
const persist=()=>ls.set('p:'+mainPath,values);
const lit=p=>{const v=values[p.name];return p.type==='string'?JSON.stringify(String(v)):p.type==='bool'?String(!!v):String(v)};

// ---------- presets (saved per file; import/export uses OpenSCAD's parameter-set JSON) ----------
const getPre=()=>ls.get('pre:'+mainPath,{});
function refreshPre(){$('#preset').innerHTML='<option value="">Presets…</option>'+Object.keys(getPre()).map(n=>`<option>${esc(n)}</option>`).join('')}
const apply=o=>{values={...defaults,...o};persist();buildUI();render()};
$('#preset').onchange=e=>{const p=getPre()[e.target.value];if(p)apply(p)};
$('#preset-reset').onclick=()=>{if(mainPath)apply({})};
$('#psave').onclick=()=>{if(!mainPath)return;const n=prompt('Preset name');if(!n)return;const p=getPre();p[n]={...values};ls.set('pre:'+mainPath,p);refreshPre();$('#preset').value=n};
$('#pdel').onclick=()=>{const n=$('#preset').value;if(!n||!confirm(`Delete "${n}"?`))return;const p=getPre();delete p[n];ls.set('pre:'+mainPath,p);refreshPre()};
$('#pexp').onclick=()=>{
  if(!mainPath)return;const sets={};
  for(const [n,v] of Object.entries(getPre()))sets[n]=Object.fromEntries(Object.entries(v).map(([k,x])=>[k,String(x)]));
  share(new File([JSON.stringify({parameterSets:sets,fileFormatVersion:'1'},null,1)],stem()+'.json',{type:'application/json'}));
};
$('#pimp').onchange=async e=>{
  const f=e.target.files[0];e.target.value='';if(!f||!mainPath)return;
  try{
    const j=JSON.parse(await f.text()),p=getPre();
    for(const [n,s] of Object.entries(j.parameterSets||{})){
      const o={};for(const q of params){if(!(q.name in s))continue;const x=s[q.name];o[q.name]=q.type==='number'?parseFloat(x):q.type==='bool'?x==='true':x}
      p[n]=o;
    }
    ls.set('pre:'+mainPath,p);refreshPre();status('Presets imported');
  }catch{status('Invalid preset file')}
};

// ---------- render / export ----------
const stem=()=>mainPath.split('/').pop().replace(/\.scad$/i,'');
function render(){
  if(!mainPath)return;
  worker?.terminate();worker=new Worker('worker.js',{type:'module'});
  const t0=performance.now();status('Rendering…');$('#export').disabled=true;
  worker.onmessage=({data})=>{
    $('#log').textContent=(data.log||[]).join('\n');
    if(data.error)return status(data.error);
    stl=data.stl;const {tris,size}=viewer.load(stl);
    status(`${mainPath} · ${tris} tris · ${size.map(x=>x.toFixed(1)).join(' × ')} mm · ${((performance.now()-t0)/1000).toFixed(1)}s`);
    $('#export').disabled=false;
  };
  worker.onerror=e=>status('Worker error: '+(e.message||'could not load openscad.js'));
  worker.postMessage({files,main:mainPath,defs:params.map(p=>`${p.name}=${lit(p)}`)});
}
$('#render').onclick=render;
async function share(f){
  try{if(navigator.canShare?.({files:[f]})){await navigator.share({files:[f]});return}}catch(e){if(e.name==='AbortError')return}
  const a=document.createElement('a');a.href=URL.createObjectURL(f);a.download=f.name;a.click();
}
$('#export').onclick=()=>stl&&share(new File([stl],stem()+'.stl',{type:'model/stl'}));
if('serviceWorker' in navigator)navigator.serviceWorker.register('sw.js').catch(()=>{});
