import {parseCustomizer} from './customizer.js';
import {Viewer} from './viewer.js';
import {unzip} from './zip.js';
const $=s=>document.querySelector(s);
const viewer=new Viewer($('#gl'));
let files={},mainPath=null,params=[],values={},worker=null,stl=null,timer=null;
const status=t=>$('#status').textContent=t;
const dec=new TextDecoder();

$('#file').onchange=async e=>{
  files={};
  for(const f of e.target.files){
    const buf=await f.arrayBuffer();
    if(/\.zip$/i.test(f.name)) Object.assign(files,await unzip(buf));
    else files[f.name]=new Uint8Array(buf);
  }
  const scads=Object.keys(files).filter(n=>/\.scad$/i.test(n)&&!n.startsWith('__MACOSX'))
    .sort((a,b)=>a.split('/').length-b.split('/').length||a.localeCompare(b)).slice(0,300);
  if(!scads.length)return status('No .scad file found');
  $('#main').innerHTML=scads.map(n=>`<option>${n}</option>`).join('');
  $('#main').disabled=false;
  pick(scads[0]);
};
$('#main').onchange=e=>pick(e.target.value);

function pick(name){
  mainPath=name;
  params=parseCustomizer(dec.decode(files[name]));
  let saved={};try{saved=JSON.parse(localStorage.getItem('p:'+name)||'{}')}catch{}
  values={};for(const p of params)values[p.name]=p.name in saved?saved[p.name]:p.def;
  buildUI();
  $('#render').disabled=false;
  render();
}

function buildUI(){
  const box=$('#params');box.innerHTML='';
  const groups={};for(const p of params)(groups[p.group]??=[]).push(p);
  for(const [g,list] of Object.entries(groups)){
    const d=document.createElement('details');d.open=true;
    d.innerHTML=`<summary>${esc(g)}</summary>`;
    for(const p of list)d.append(row(p));
    box.append(d);
  }
  if(!params.length)box.innerHTML='<small>No Customizer parameters found in this file.</small>';
}
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

function row(p){
  const r=document.createElement('div');r.className='row';
  const l=document.createElement('label');l.innerHTML=esc(p.name)+(p.desc?`<small>${esc(p.desc)}</small>`:'');
  let inp,get=()=>inp.value;
  const set=v=>{values[p.name]=v;persist();if($('#auto').checked){clearTimeout(timer);timer=setTimeout(render,400)}};
  if(p.type==='bool'){inp=document.createElement('input');inp.type='checkbox';inp.checked=values[p.name]===true;inp.onchange=()=>set(inp.checked)}
  else if(p.options){
    inp=document.createElement('select');
    inp.innerHTML=p.options.map(o=>`<option value="${esc(o.v)}">${esc(o.label)}</option>`).join('');
    inp.value=String(values[p.name]);inp.onchange=()=>set(p.type==='number'?+inp.value:inp.value);
  }else if(p.range){
    inp=document.createElement('input');inp.type='range';
    Object.assign(inp,{min:p.range[0],max:p.range[2],step:p.range[1]});inp.value=values[p.name];
    const v=document.createElement('span');v.className='val';v.textContent=inp.value;l.prepend(v);
    inp.oninput=()=>{v.textContent=inp.value};inp.onchange=()=>set(+inp.value);
  }else if(p.type==='number'){inp=document.createElement('input');inp.type='number';inp.step='any';inp.value=values[p.name];inp.onchange=()=>set(+inp.value)}
  else{inp=document.createElement('input');inp.type='text';inp.value=values[p.name];inp.onchange=()=>set(inp.value)}
  r.append(l,inp);return r;
}
const persist=()=>{try{localStorage.setItem('p:'+mainPath,JSON.stringify(values))}catch{}};
const lit=p=>{const v=values[p.name];return p.type==='string'?JSON.stringify(String(v)):p.type==='bool'?String(!!v):String(v)};

function render(){
  if(!mainPath)return;
  worker?.terminate();worker=new Worker('worker.js',{type:'module'});
  const t0=performance.now();status('Rendering…');$('#export').disabled=true;
  worker.onmessage=({data})=>{
    $('#log').textContent=(data.log||[]).join('\n');
    if(data.error)return status(data.error);
    stl=data.stl;const n=viewer.load(stl);
    status(`${mainPath} · ${n} triangles · ${((performance.now()-t0)/1000).toFixed(1)}s`);
    $('#export').disabled=false;
  };
  worker.onerror=e=>status('Worker error: '+(e.message||'could not load openscad.js'));
  worker.postMessage({files,main:mainPath,defs:params.map(p=>`${p.name}=${lit(p)}`)});
}
$('#render').onclick=render;

$('#export').onclick=async()=>{
  if(!stl)return;
  const name=mainPath.split('/').pop().replace(/\.scad$/i,'')+'.stl';
  const f=new File([stl],name,{type:'model/stl'});
  try{if(navigator.canShare?.({files:[f]})){await navigator.share({files:[f]});return}}catch(e){if(e.name==='AbortError')return}
  const a=document.createElement('a');a.href=URL.createObjectURL(f);a.download=name;a.click();
};
if('serviceWorker' in navigator)navigator.serviceWorker.register('sw.js').catch(()=>{});
