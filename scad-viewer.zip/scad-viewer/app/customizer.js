// Parses OpenSCAD Customizer conventions: /* [Group] */, "// description", "// [min:max]" / "// [a,b,c]" / "// [1:Label, 2:Label]".
const LIT=/^(-?\d*\.?\d+(?:[eE][-+]?\d+)?|"[^"]*"|true|false|\[[^\]]*\])$/;
export function parseCustomizer(src){
  const out=[];let group='Parameters',hidden=false,depth=0,desc='';
  for(const raw of src.split('\n')){
    const line=raw.trim();
    if(depth===0){
      const g=line.match(/^\/\*\s*\[(.+?)\]\s*\*\//);
      if(g){group=g[1].trim();hidden=/^hidden$/i.test(group);desc='';continue}
      const m=raw.match(/^([A-Za-z_]\w*)\s*=\s*(.+?)\s*;\s*(?:\/\/\s*(.*))?$/);
      if(m&&!hidden&&LIT.test(m[2])){
        const [,name,v,c='']=m;const p={name,group,desc:desc};
        if(v==='true'||v==='false'){p.type='bool';p.def=v==='true'}
        else if(v[0]==='"'){p.type='string';p.def=v.slice(1,-1)}
        else if(v[0]==='['){p.type='vector';p.def=v}
        else{p.type='number';p.def=parseFloat(v)}
        const o=c.trim().match(/^\[(.*)\]$/);
        if(o&&p.type!=='bool'&&p.type!=='vector'){
          const body=o[1];
          const nums=body.split(':').map(s=>s.trim());
          if(nums.length>=2&&nums.length<=3&&nums.every(s=>/^-?\d*\.?\d+$/.test(s))&&p.type==='number'){
            const [a,b,c3]=nums.map(Number);p.range=nums.length===2?[a,1,b]:[a,b,c3];
          }else p.options=body.split(',').map(s=>{
            const i=s.indexOf(':');const val=(i<0?s:s.slice(0,i)).trim(),label=(i<0?s:s.slice(i+1)).trim();
            return {v:val,label};
          }).filter(x=>x.v!=='');
          if(p.options&&p.type==='number'&&p.options.some(x=>isNaN(+x.v)))delete p.options;
        }else if(c.trim()&&!/^\[/.test(c.trim()))p.desc=c.trim();
        out.push(p);desc='';
      }else if(line.startsWith('//'))desc=line.replace(/^\/\/\s*/,'');
      else if(line&&!line.startsWith('/*'))desc='';
    }
    const code=raw.replace(/"[^"]*"/g,'').replace(/\/\/.*$/,'');
    depth=Math.max(0,depth+(code.match(/\{/g)||[]).length-(code.match(/\}/g)||[]).length);
  }
  return out;
}
